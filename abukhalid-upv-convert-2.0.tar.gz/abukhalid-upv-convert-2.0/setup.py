from setuptools import setup, find_packages

setup(
    name="abukhalid-upv-convert",  # Replace with your package name
    version="2.0",  # Initial release version
    author="A.I.Alnour",
    author_email="abwk0413@gmail.com",
    description="A upv-convert is converting upv markup to moodle format",
    long_description=open("README.md").read(),  # Long description from README file
    long_description_content_type="text/markdown",  # Content type for the long description
    #url="https://github.com/yourusername/your-repo-name",  # URL to the project's repository
    packages=find_packages(),  # Automatically find and include all packages in the project
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.10",  # Minimum Python version required
    
    extras_require={
        "dev": ["check-manifest"],
        "test": ["coverage"],
        }
)