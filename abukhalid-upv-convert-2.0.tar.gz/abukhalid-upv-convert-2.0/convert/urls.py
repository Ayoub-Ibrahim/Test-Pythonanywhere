from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [

    path('', views.home, name='home'),
    path('multichoice/', views.multichoice, name='multichoice'),
    path('numeric/', views.numerical, name='numeric'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout' ),
    path('register/', views.register, name='register'),
    path('edit/', views.edit, name='edit'),
    path('password-change/',auth_views.PasswordChangeView.as_view(),name='password_change'),
    path('password-change/done/',auth_views.PasswordChangeDoneView.as_view(),name='password_change_done'),
    path('help/', views.help, name='help'),
    path('about/', views.about, name='about'),
]

